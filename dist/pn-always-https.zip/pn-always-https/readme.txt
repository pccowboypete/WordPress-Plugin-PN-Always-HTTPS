PM Always HTTPS
 * Description: Very simple but effective HTTPS redirect plugin.
 * Author: Peter Nanayon
 * Author URI: https://peternanayon.online
 * Version: 1.0.0
 * License: GPL v2
 * License URI: https://www.gnu.org/licenses/old-licenses/gpl-2.0.en.html
 * Update URI: https://dev.peternanayon.online/release/wordpress/plugins/pn-always-https/
 * Text Domain: pn-always-https
 * Domain Path: /languages
 */